"""Smoke tests: the package imports and the server can be constructed."""

import cloudflare_mcp_server
from cloudflare_mcp_server import CloudflareMCPServer


def test_module_exposes_entrypoint():
    assert callable(cloudflare_mcp_server.main)


async def test_server_constructs():
    server = CloudflareMCPServer(api_token="test-token", account_id="acct")
    assert server.server is not None
    await server.client.aclose()
